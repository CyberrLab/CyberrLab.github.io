# Cyber Portfolio Starter

Open index.html or use VS Code Live Server.

To publish:
1. Push to CyberrLab.github.io repository.
2. GitHub -> Settings -> Pages -> Deploy from branch -> main /(root).
